import json
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.db import models
from django.utils.timezone import now
from django.db.models import F, Q
from .models import Medicine, StockOrder, CustomerOrder
from django.contrib.auth import authenticate, login
from django.contrib.auth import get_user_model
# views.py

User = get_user_model()

@csrf_exempt
def signup(request):
    if request.method == "POST":
        data = json.loads(request.body)
        username = data.get("username")
        password = data.get("password")
        role = data.get("role")
        print(f"[SIGNUP] username={username}, password={password}, role={role}")
        if not role in ['admin', 'customer']:
            return JsonResponse({"error": "Invalid role"}, status=400)

        if User.objects.filter(username=username).exists():
            return JsonResponse({"error": "Username already exists"}, status=400)

        user = User.objects.create_user(username=username, password=password, role=role)
        print(f"[SIGNUP] Created user: {user.username}, role={user.role}")
        return JsonResponse({"message": "User created successfully", "role": role})

@csrf_exempt
def user_login(request):
    if request.method == "POST":
        data = json.loads(request.body)
        username = data.get("username")
        password = data.get("password")
        print(f"[LOGIN] username={username}, password={password}")
        user = authenticate(username=username, password=password)
        print(f"[LOGIN] user={user}")
        if user is None:
            return JsonResponse({"error": "Invalid credentials"}, status=401)

        login(request, user)  # Optional: log in session
        return JsonResponse({
            "message": "Login successful", 
            "username": user.username,
            "role": user.role
        })


@csrf_exempt
def medicine_list(request):
    if request.method == "GET":
        medicines = Medicine.objects.all()
        data = [m.to_dict() for m in medicines]
        return JsonResponse(data, safe=False)

    elif request.method == "POST":
        body = json.loads(request.body)
        name = body.get("name")
        brand = body.get("brand")
        price = body.get("price")
        stock_quantity = body.get("stock_quantity")
        min_stock_level = body.get("min_stock_level")
        # Check for existing medicine with same name and brand
        try:
            medicine = Medicine.objects.get(name=name, brand=brand)
            # Update existing medicine
            medicine.price = price
            medicine.stock_quantity = stock_quantity
            medicine.min_stock_level = min_stock_level
            medicine.save()
            return JsonResponse(medicine.to_dict(), status=200)
        except Medicine.DoesNotExist:
            # Create new medicine
            medicine = Medicine.objects.create(
                name=name,
                brand=brand,
                price=price,
                stock_quantity=stock_quantity,
                min_stock_level=min_stock_level
            )
            return JsonResponse(medicine.to_dict(), status=201)

@csrf_exempt
def medicine_detail(request, id):
    try:
        medicine = Medicine.objects.get(pk=id)
    except Medicine.DoesNotExist:
        return JsonResponse({"error": "Not found"}, status=404)

    if request.method == "GET":
        return JsonResponse(medicine.to_dict())

    elif request.method == "PUT":
        data = json.loads(request.body)
        medicine.name = data.get("name", medicine.name)
        medicine.brand = data.get("brand", medicine.brand)
        medicine.price = data.get("price", medicine.price)
        medicine.stock_quantity = data.get("stock_quantity", medicine.stock_quantity)
        medicine.min_stock_level = data.get("min_stock_level", medicine.min_stock_level)
        medicine.save()
        return JsonResponse(medicine.to_dict())

    elif request.method == "DELETE":
        medicine.delete()
        return JsonResponse({"message": "Deleted successfully"})

@csrf_exempt
def dashboard_summary(request):
    if request.method == "GET":
        # 1. Low stock medicines
        low_stock_medicines = Medicine.objects.filter(stock_quantity__lte=F("min_stock_level"))
        low_stock = [
            {
                "id": med.id,
                "name": med.name,
                "brand": med.brand,
                "stock_quantity": med.stock_quantity,
                "min_stock_level": med.min_stock_level,
            }
            for med in low_stock_medicines
        ]

        # 2. Pending stock orders (case-insensitive)
        pending_orders = StockOrder.objects.filter(Q(status__iexact="pending"))
        pending = [
            {
                "id": order.id,
                "medicine_id": order.medicine_id,
                "quantity": order.quantity,
                "supplier": order.supplier,
                "status": order.status,
                "created_at": order.created_at.strftime("%Y-%m-%d %H:%M:%S"),
            }
            for order in pending_orders
        ]

        # 3. Today's revenue
        today = now().date()
        today_orders = CustomerOrder.objects.filter(created_at__date=today)  # adjust if field is different
        today_revenue = sum(order.total_amount for order in today_orders)

        return JsonResponse({
            "low_stock": low_stock,
            "pending_orders": pending,
            "today_revenue": float(today_revenue),
        })
    
@csrf_exempt
def stock_order_list(request):
    if request.method == "GET":
        orders = StockOrder.objects.all()
        data = [
            {
                "id": order.id,
                "medicine_id": order.medicine.id,
                "medicine_name": order.medicine.name,
                "quantity": order.quantity,
                "unit_price": float(order.unit_price),
                "supplier": order.supplier,
                "status": order.status,
                "created_at": order.created_at.strftime("%Y-%m-%d %H:%M:%S")
            }
            for order in orders
        ]
        return JsonResponse(data, safe=False)

    elif request.method == "POST":
        body = json.loads(request.body)
        medicine = Medicine.objects.get(id=body["medicine_id"])
        order = StockOrder.objects.create(
            medicine=medicine,
            quantity=body["quantity"],
            unit_price=body["unit_price"],
            supplier=body["supplier"],
            status=body.get("status", "pending")
        )
        return JsonResponse({
            "id": order.id,
            "medicine_id": order.medicine.id,
            "quantity": order.quantity,
            "unit_price": float(order.unit_price),
            "supplier": order.supplier,
            "status": order.status,
            "created_at": order.created_at.strftime("%Y-%m-%d %H:%M:%S")
        }, status=201)

@csrf_exempt
def update_stock_order_status(request, id):
    try:
        order = StockOrder.objects.get(pk=id)
    except StockOrder.DoesNotExist:
        return JsonResponse({"error": "Order not found"}, status=404)

    if request.method == "PUT":
        data = json.loads(request.body)
        new_status = data.get("status")

        if new_status not in ["pending", "arrived"]:
            return JsonResponse({"error": "Invalid status"}, status=400)

        # If changed to 'arrived', update medicine stock
        if order.status != "arrived" and new_status == "arrived":
            order.medicine.stock_quantity += order.quantity
            order.medicine.save()

        order.status = new_status
        order.save()

        return JsonResponse({
            "id": order.id,
            "medicine": order.medicine.name,
            "status": order.status,
            "updated_stock": order.medicine.stock_quantity,
        })


@csrf_exempt
def customer_orders(request):
    if request.method == "GET":
        orders = CustomerOrder.objects.all().order_by("-created_at")
        data = []
        for order in orders:
            items = order.items.all()
            item_list = [
                {
                    "medicine_id": item.medicine.id,
                    "medicine_name": item.medicine.name,
                    "quantity": item.quantity,
                    "unit_price": float(item.unit_price)
                }
                for item in items
            ]
            data.append({
                "id": order.id,
                "customer_name": order.customer_name,
                "total_amount": float(order.total_amount),
                "status": order.status,
                "created_at": order.created_at.strftime("%Y-%m-%d %H:%M:%S"),
                "items": item_list
            })
        return JsonResponse(data, safe=False)

    elif request.method == "POST":
        data = json.loads(request.body)
        customer_name = data.get("customer_name")
        items = data.get("items", [])  # list of {medicine_id, quantity}

        if not items:
            return JsonResponse({"error": "No items in order"}, status=400)

        total = 0
        order = CustomerOrder.objects.create(customer_name=customer_name)

        for item in items:
            try:
                med = Medicine.objects.get(id=item["medicine_id"])
            except Medicine.DoesNotExist:
                order.delete()
                return JsonResponse({"error": "Medicine not found"}, status=404)

            quantity = item["quantity"]
            price = med.price

            # Check stock availability
            if med.stock_quantity < quantity:
                order.delete()
                return JsonResponse({"error": f"Not enough stock for {med.name}"}, status=400)

            # Deduct stock
            med.stock_quantity -= quantity
            med.save()

            total += price * quantity

            # Create order item
            order.items.create(medicine=med, quantity=quantity, unit_price=price)

        order.total_amount = total
        order.save()

        return JsonResponse({"message": "Order created", "order_id": order.id})

@csrf_exempt
def update_customer_order_status(request, id):
    try:
        order = CustomerOrder.objects.get(pk=id)
    except CustomerOrder.DoesNotExist:
        return JsonResponse({"error": "Order not found"}, status=404)

    if request.method == "PUT":
        data = json.loads(request.body)
        new_status = data.get("status")
        if new_status not in ["pending", "successful"]:
            return JsonResponse({"error": "Invalid status"}, status=400)
        order.status = new_status
        order.save()
        return JsonResponse({
            "id": order.id,
            "status": order.status,
        })
