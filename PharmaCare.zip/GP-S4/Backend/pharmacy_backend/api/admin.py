from django.contrib import admin
from .models import Medicine, StockOrder, CustomerOrder, CustomerOrderItem, User

admin.site.register(User)
admin.site.register(Medicine)
admin.site.register(StockOrder)

class CustomerOrderItemInline(admin.TabularInline):
    model = CustomerOrderItem
    extra = 0
    readonly_fields = ("medicine", "quantity", "unit_price")

@admin.register(CustomerOrder)
class CustomerOrderAdmin(admin.ModelAdmin):
    list_display = ("id", "customer_name", "total_amount", "status", "created_at")
    list_editable = ("status",)
    list_filter = ("status", "created_at")
    search_fields = ("customer_name",)
    inlines = [CustomerOrderItemInline]
