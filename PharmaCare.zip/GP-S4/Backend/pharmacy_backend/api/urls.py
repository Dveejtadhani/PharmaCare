from django.urls import path
from . import views

urlpatterns = [
    path("medicines/", views.medicine_list),
    path("medicines/<int:id>/", views.medicine_detail),
    path("stock-orders/", views.stock_order_list),
    path("stock-orders/<int:id>/", views.update_stock_order_status),
    path("customer-orders/", views.customer_orders),
    path("customer-orders/<int:id>/", views.update_customer_order_status),
    path("dashboard/", views.dashboard_summary),
    path("signup/", views.signup),
    path("login/", views.user_login),
]
