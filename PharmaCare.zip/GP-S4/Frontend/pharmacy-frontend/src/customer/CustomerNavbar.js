import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { FaSignOutAlt, FaCartPlus, FaUserCircle, FaClipboardList, FaHome, FaUser } from "react-icons/fa";

const CustomerNavbar = () => {
  const navigate = useNavigate();
  const logout = () => {
    localStorage.removeItem('user');
    navigate('/login');
  };
  
  return (
    <nav className="glass-effect shadow-lg" style={{ 
      margin: 'var(--spacing-lg) var(--spacing-xl)', 
      padding: 'var(--spacing-md) var(--spacing-xl)', 
      position: 'sticky', 
      top: 0, 
      zIndex: 100,
      borderRadius: 'var(--radius-2xl)'
    }}>
      <div className="container-fluid">
        <Link className="navbar-brand fw-bold d-flex align-items-center" to="/customer" style={{ 
          fontSize: '2rem', 
          letterSpacing: '1px',
          textDecoration: 'none'
        }}>
          <span className="gradient-text me-2">pharma</span>
          <span style={{ color: 'var(--secondary-color)', fontWeight: 700 }}>care</span>
          <div className="status-indicator status-online ms-2"></div>
        </Link>
        
        <div>
          <ul className="navbar-nav me-auto mb-2 mb-lg-0 d-flex flex-row gap-2 align-items-center">
            <li className="nav-item">
              <Link className="nav-link custom-nav-link d-flex align-items-center" to="/customer">
                <FaHome className="me-2" />
                <span className="d-none d-md-inline">Browse</span>
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link custom-nav-link d-flex align-items-center" to="/customer/cart">
                <FaCartPlus className="me-2" />
                <span className="d-none d-md-inline">Cart</span>
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link custom-nav-link d-flex align-items-center" to="/customer/orders">
                <FaClipboardList className="me-2" />
                <span className="d-none d-md-inline">My Orders</span>
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link custom-nav-link d-flex align-items-center" to="/customer/profile">
                <FaUser className="me-2" />
                <span className="d-none d-md-inline">Profile</span>
              </Link>
            </li>
            <li className="nav-item ms-2">
              <button 
                className="btn btn-danger d-flex align-items-center glow-effect" 
                onClick={logout} 
                style={{
                  borderRadius: 'var(--radius-xl)',
                  padding: 'var(--spacing-sm) var(--spacing-lg)',
                  transition: 'all 0.3s ease'
                }}
              >
                <FaSignOutAlt className="me-2" />
                <span className="d-none d-md-inline">Logout</span>
              </button>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
};

export default CustomerNavbar; 