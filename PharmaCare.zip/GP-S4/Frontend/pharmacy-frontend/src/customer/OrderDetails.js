import React from 'react';
import orderThemeImg from '../images/order-theme.png'; // Use your theme image here
import otrivinImg from '../images/2.webp'; // Example product image

const order = {
  status: 'Delivered',
  items: [
    { image: otrivinImg, name: 'Otrivin', qty: 4, price: 12 }
  ],
  total: 38.40,
  delivery: 'Free',
  invoice: '788152',
  date: '12/15/2023, 10:21:35 PM',
  voucher: '657cb54f4df759b364c72a8a'
};

const OrderDetails = () => (
  <div style={{
    maxWidth: 700,
    margin: '40px auto',
    borderRadius: 12,
    boxShadow: '0 4px 24px #0002',
    background: '#f8fafc'
  }}>
    {/* Banner */}
    <div style={{
      background: '#6ec1e4',
      borderTopLeftRadius: 12,
      borderTopRightRadius: 12,
      padding: '24px 0',
      textAlign: 'center',
      position: 'relative'
    }}>
      <img src={orderThemeImg} alt="Order Theme" style={{ height: 60, marginBottom: 8 }} />
      <h2 style={{ color: '#fff', fontWeight: 700, margin: 0 }}>Order Details</h2>
    </div>
    {/* Main Card */}
    <div style={{
      background: '#fff',
      borderRadius: '0 0 12px 12px',
      padding: 32,
      position: 'relative',
      overflow: 'hidden'
    }}>
      {/* Faded background image */}
      <img
        src={orderThemeImg}
        alt="Order Theme Faded"
        style={{
          position: 'absolute',
          top: 20,
          right: 20,
          width: 120,
          opacity: 0.08,
          zIndex: 0,
          pointerEvents: 'none'
        }}
      />
      <div style={{ position: 'relative', zIndex: 1 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 16 }}>
          <span style={{ color: '#6ec1e4', fontWeight: 600, fontSize: 18 }}>Receipt</span>
          <span style={{ color: '#888', fontWeight: 500 }}>Order Status: <b>{order.status}</b></span>
        </div>
        {/* Product Row */}
        <div style={{
          border: '1px solid #e5e7eb',
          borderRadius: 8,
          padding: 24,
          marginBottom: 24,
          background: '#f9fafb'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 24 }}>
            <img src={order.items[0].image} alt={order.items[0].name} style={{ width: 64, height: 80, objectFit: 'contain', borderRadius: 8 }} />
            <div style={{ fontWeight: 600 }}>{order.items[0].name}</div>
            <div>Qty: {order.items[0].qty}</div>
            <div>${order.items[0].price}</div>
          </div>
          {/* Progress Bar */}
          <div style={{ marginTop: 24 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 14, color: '#888', marginBottom: 4 }}>
              <span>Track Order</span>
              <span>Out for delivery</span>
              <span>Delivered</span>
            </div>
            <div style={{ height: 6, background: '#e0e7ef', borderRadius: 3, position: 'relative' }}>
              <div style={{
                width: '100%',
                height: '100%',
                background: '#6ec1e4',
                borderRadius: 3
              }} />
            </div>
          </div>
        </div>
        {/* Order Details */}
        <div style={{ marginTop: 16 }}>
          <div style={{ fontWeight: 700, marginBottom: 8 }}>Order Details</div>
          <div>Invoice Number : {order.invoice}</div>
          <div>Invoice Date : {order.date}</div>
          <div>Receipts Voucher : {order.voucher}</div>
          <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 16 }}>
            <div style={{ marginRight: 32 }}>
              <div><b>Total</b> {order.total.toFixed(2)}</div>
              <div><b>Delivery Charges</b> {order.delivery}</div>
            </div>
            <div>
              <div><b>Total paid:</b> {order.total.toFixed(2)}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
);

export default OrderDetails; 