import React, { useEffect, useState } from 'react';
import cartThemeImg from '../images/2.webp';
import { useNavigate } from 'react-router-dom';

const MyOrder = () => {
  const [orders, setOrders] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    fetch('http://localhost:8000/api/customer-orders/')
      .then(res => res.json())
      .then(data => setOrders(data));
  }, []);

  const markAsSuccessful = async (orderId) => {
    await fetch(`http://localhost:8000/api/customer-orders/${orderId}/`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: 'successful' })
    });
    // Refresh orders
    fetch('http://localhost:8000/api/customer-orders/')
      .then(res => res.json())
      .then(data => setOrders(data));
  };

  return (
    <div className="container mx-auto p-4">
      <h1 style={{ color: '#2563eb', fontWeight: 700, marginBottom: 24 }}>My Orders</h1>
      {orders.length === 0 ? (
        <div>No orders found.</div>
      ) : (
        orders.map(order => (
          <div key={order.id} style={{
            background: '#fff',
            borderRadius: 12,
            boxShadow: '0 2px 8px #0001',
            marginBottom: 32,
            padding: 24,
            position: 'relative'
          }}>
            
            <div style={{ position: 'relative', zIndex: 1 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                <span style={{ color: '#6ec1e4', fontWeight: 600 }}>Order #{order.id}</span>
                <span style={{ color: order.status === 'pending' ? '#f59e42' : '#16a34a', fontWeight: 600 }}>
                  {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                </span>
              </div>
              <div>
                {order.items && order.items.map(item => (
                  <div key={item.medicine_id} style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 8 }}>
                    <img src={cartThemeImg} alt={item.medicine_name} style={{ width: 40, height: 50, objectFit: 'contain', borderRadius: 6 }} />
                    <div style={{color: '#22223b'}}>{item.medicine_name}</div>
                    <div style={{color: '#22223b'}}>Qty: {item.quantity}</div>
                    <div style={{color: '#22223b'}}>${item.unit_price}</div>
                  </div>
                ))}
              </div >
              <div style={{ marginTop: 8 }}>
                <b style={{color: '#22223b'}}>Total:₹{order.total_amount}</b> 
              </div>
              <div style={{ marginTop: 8, color: '#888', fontSize: 13 }}>
                Placed on: {order.created_at}
              </div>
            </div>
          </div>
        ))
      )}
      <div style={{ display: 'flex', justifyContent: 'center', marginTop: 32 }}>
        <button
          onClick={() => navigate('/customer')}
          style={{
            background: '#6ec1e4',
            color: '#fff',
            border: 'none',
            borderRadius: 8,
            padding: '12px 32px',
            fontWeight: 700,
            fontSize: 16,
            cursor: 'pointer',
            boxShadow: '0 2px 8px #0001',
            transition: 'background 0.2s'
          }}
          onMouseOver={e => e.currentTarget.style.background = '#2563eb'}
          onMouseOut={e => e.currentTarget.style.background = '#6ec1e4'}
        >
          Go to Browse Medicines
        </button>
      </div>
    </div>
  );
};

export default MyOrder;
