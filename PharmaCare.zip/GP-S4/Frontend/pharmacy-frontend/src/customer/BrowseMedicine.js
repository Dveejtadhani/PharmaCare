import React, { useEffect, useState } from 'react';
import { FaSearch, FaCartPlus, FaInfoCircle, FaSignOutAlt, FaUserCircle, FaClipboardList, FaFilter, FaSort, FaStar, FaTag } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';
// Import local images
import paracetamolImg from '../images/3.jpg';
import ibuprofenImg from '../images/4.jpg';
import defaultImg from '../images/1.webp';
import CustomerNavbar from './CustomerNavbar';

const imageMap = {
  Paracetamol: paracetamolImg,
  Ibuprofen: ibuprofenImg,
  // Add more mappings as needed
};

const PLACEHOLDER_IMAGE = 'https://via.placeholder.com/150x100?text=Medicine';

const BrowseMedicine = () => {
  const [medicines, setMedicines] = useState([]);
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState(null);
  const [cart, setCart] = useState(() => JSON.parse(localStorage.getItem('cart') || '[]'));
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    setIsLoading(true);
    fetch('http://localhost:8000/api/medicines/')
      .then(res => res.json())
      .then(data => {
        setMedicines(data);
        setIsLoading(false);
      })
      .catch(err => {
        console.error('Error fetching medicines:', err);
        setIsLoading(false);
      });
  }, []);

  useEffect(() => {
    localStorage.setItem('cart', JSON.stringify(cart));
  }, [cart]);

  const addToCart = (med) => {
    setCart(prev => {
      const found = prev.find(item => item.id === med.id);
      if (found) {
        return prev.map(item => item.id === med.id ? { ...item, qty: item.qty + 1 } : item);
      }
      // Always include the image property
      return [...prev, { ...med, qty: 1, image: imageMap[med.name] || defaultImg }];
    });
    navigate('/customer/cart');
  };

  const logout = () => {
    localStorage.removeItem('user');
    navigate('/login');
  };

  const filtered = medicines.filter(m =>
    m.name.toLowerCase().includes(search.toLowerCase()) ||
    m.brand.toLowerCase().includes(search.toLowerCase())
  );

  if (isLoading) {
    return (
      <div>
        <CustomerNavbar />
        <div className="d-flex justify-content-center align-items-center" style={{ minHeight: '100vh', background: 'var(--bg-primary)' }}>
          <div className="text-center">
            <div className="loading-spinner mb-3"></div>
            <p className="text-muted">Loading medicines...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <>
     
      <div className="fade-in" style={{ 
        minHeight: '100vh',
        background: 'var(--bg-primary)', 
        position: 'relative',
        padding: 'var(--spacing-xl) 0'
      }}>
        {/* Animated Background Elements */}
        <div style={{ 
          position: 'absolute', 
          top: 0, 
          left: 0, 
          right: 0, 
          bottom: 0,
          background: `
            radial-gradient(circle at 20% 80%, rgba(99, 102, 241, 0.05) 0%, transparent 50%),
            radial-gradient(circle at 80% 20%, rgba(16, 185, 129, 0.05) 0%, transparent 50%),
            radial-gradient(circle at 40% 40%, rgba(139, 92, 246, 0.03) 0%, transparent 50%)
          `,
          pointerEvents: 'none'
        }}></div>

        <div style={{ position: 'relative', zIndex: 1 }}>
          {/* Header Section */}
          <div className="container mb-5">
            <div className="text-center mb-4">
              <h1 className="gradient-text mb-3">Browse Medicines</h1>
              <p className="text-subtle">Find and order your medications with ease</p>
            </div>

            {/* Search Bar */}
            <div className="row justify-content-center mb-5">
              <div className="col-md-8 col-lg-6">
                <div className="glass-effect shadow-lg" style={{ borderRadius: 'var(--radius-2xl)', padding: 'var(--spacing-lg)' }}>
                  <div className="input-group">
                    <span className="input-group-text bg-transparent border-end-0">
                      <FaSearch className="text-muted" />
                    </span>
                    <input
                      className="form-control border-start-0"
                      placeholder="Search medicines by name or brand..."
                      value={search}
                      onChange={e => setSearch(e.target.value)}
                      style={{ background: 'transparent' }}
                    />
                    <button className="btn btn-outline-secondary border-start-0">
                      <FaFilter />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Medicines Grid */}
          <div className="container" style={{ maxWidth: 1400 }}>
            {filtered.length === 0 ? (
              <div className="text-center py-5">
                <div className="modern-card p-5" style={{ maxWidth: '400px', margin: '0 auto' }}>
                  <FaInfoCircle size={64} className="text-muted mb-4" />
                  <h3 className="text-muted mb-3">No Medicines Found</h3>
                  <p className="text-muted">Try adjusting your search terms or browse our full catalog.</p>
                </div>
              </div>
            ) : (
              <div className="row g-4">
                {filtered.slice(0, 12).map(med => (
                  <div className="col-12 col-sm-6 col-md-4 col-lg-3" key={med.id}>
                    <div className="modern-card h-100 d-flex flex-column">
                      <div className="position-relative">
                        <img
                          src={imageMap[med.name] || defaultImg}
                          alt={med.name}
                          className="card-img-top"
                          style={{ 
                            height: 200, 
                            objectFit: 'cover', 
                            borderTopLeftRadius: 'var(--radius-xl)', 
                            borderTopRightRadius: 'var(--radius-xl)'
                          }}
                        />
                        {med.stock_quantity <= med.min_stock_level && (
                          <div className="position-absolute top-0 end-0 m-2">
                            <span className="badge-modern-secondary glow-effect">Low Stock</span>
                          </div>
                        )}
                        <div className="position-absolute bottom-0 start-0 m-2">
                          <span className="badge-modern price-text-large">₹{med.price}</span>
                        </div>
                        <div className="position-absolute top-0 start-0 m-2">
                          <span className="badge bg-warning text-dark">
                            <FaStar className="me-1" />
                            Popular
                          </span>
                        </div>
                      </div>
                      
                      <div className="card-body d-flex flex-column">
                        <h5 className="card-title fw-bold mb-2 text-glow-primary">
                          {med.name}
                        </h5>
                        <p className="text-subtle mb-2">
                          <FaTag className="me-1" />
                          Brand: {med.brand}
                        </p>
                        
                        <div className="mt-auto">
                          <div className="d-flex justify-content-between align-items-center mb-3">
                            <span className={`status-text ${med.stock_quantity > med.min_stock_level ? 'status-text-success' : 'status-text-danger'}`}>
                              <span className={`status-indicator ${med.stock_quantity > med.min_stock_level ? 'status-online' : 'status-offline'}`}></span>
                              {med.stock_quantity > med.min_stock_level ? 'In Stock' : 'Out of Stock'}
                            </span>
                            <span className="text-subtle">Stock: {med.stock_quantity}</span>
                          </div>
                          
                          {med.stock_quantity > med.min_stock_level && (
                            <button 
                              className="btn btn-modern w-100 d-flex align-items-center justify-content-center" 
                              onClick={() => addToCart(med)}
                            >
                              <FaCartPlus className="me-2" />
                              Add to Cart
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Load More Button */}
            {filtered.length > 12 && (
              <div className="text-center mt-5">
                <button className="btn btn-outline-primary btn-lg">
                  Load More Medicines
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Medicine Details Modal */}
      {selected && (
        <div className="modal show d-block" tabIndex="-1" style={{ background: 'var(--bg-overlay)' }}>
          <div className="modal-dialog modal-dialog-centered">
            <div className="modern-card">
              <div className="modal-header border-bottom border-secondary">
                <h5 className="modal-title gradient-text">{selected.name} Details</h5>
                <button 
                  type="button" 
                  className="btn-close btn-close-white" 
                  onClick={() => setSelected(null)}
                ></button>
              </div>
              <div className="modal-body">
                <div className="row g-3">
                  <div className="col-6">
                    <label className="form-label fw-bold text-muted">Brand</label>
                    <p className="mb-0 text-emphasis">{selected.brand}</p>
                  </div>
                  <div className="col-6">
                    <label className="form-label fw-bold text-muted">Price</label>
                    <p className="mb-0 price-text-large">₹{selected.price}</p>
                  </div>
                  <div className="col-6">
                    <label className="form-label fw-bold text-muted">Stock Quantity</label>
                    <p className="mb-0 text-emphasis">{selected.stock_quantity}</p>
                  </div>
                  <div className="col-6">
                    <label className="form-label fw-bold text-muted">Min Stock Level</label>
                    <p className="mb-0 text-emphasis">{selected.min_stock_level}</p>
                  </div>
                </div>
              </div>
              <div className="modal-footer border-top border-secondary">
                <button className="btn btn-secondary" onClick={() => setSelected(null)}>Close</button>
                {selected.stock_quantity > selected.min_stock_level && (
                  <button className="btn btn-modern" onClick={() => {
                    addToCart(selected);
                    setSelected(null);
                  }}>
                    <FaCartPlus className="me-2" />
                    Add to Cart
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default BrowseMedicine;
