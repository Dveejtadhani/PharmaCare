import React from 'react';
import { Routes, Route, Outlet } from 'react-router-dom';
import BrowseMedicine from './BrowseMedicine';
import Cart from './Cart';
import MyOrder from './MyOrder';
import Profile from './Profile';
import CustomerNavbar from './CustomerNavbar';

const CustomerLayout = () => (
  <>
    <CustomerNavbar />
    <Outlet />
  </>
);

const CustomerRoutes = () => (
  <Routes>
    <Route element={<CustomerLayout />}>
      <Route index element={<BrowseMedicine />} />
      <Route path="cart" element={<Cart />} />
      <Route path="orders" element={<MyOrder />} />
      <Route path="profile" element={<Profile />} />
    </Route>
  </Routes>
);

export default CustomerRoutes;
