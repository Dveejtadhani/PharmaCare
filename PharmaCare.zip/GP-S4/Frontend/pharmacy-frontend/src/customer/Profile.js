import React, { useState, useEffect } from 'react';
import { FaUser, FaShieldAlt, FaEnvelope, FaPhone, FaMapMarkerAlt, FaCalendarAlt } from 'react-icons/fa';

const Profile = () => {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Get user data from localStorage
    try {
      const userData = JSON.parse(localStorage.getItem('user'));
      setUser(userData);
    } catch (e) {
      console.error('Error parsing user data:', e);
    } finally {
      setIsLoading(false);
    }
  }, []);

  if (isLoading) {
    return (
      <div className="d-flex justify-content-center align-items-center" style={{ minHeight: '100vh', background: 'var(--bg-primary)' }}>
        <div className="text-center">
          <div className="loading-spinner mb-3"></div>
          <p className="text-muted">Loading your profile...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="d-flex justify-content-center align-items-center" style={{ minHeight: '100vh', background: 'var(--bg-primary)' }}>
        <div className="text-center">
          <div className="modern-card p-4" style={{ maxWidth: '400px' }}>
            <div className="mb-3">
              <FaUser size={48} className="text-muted" />
            </div>
            <h3 className="gradient-text mb-3">No User Data</h3>
            <p className="text-muted">Please log in to view your profile information.</p>
            <button className="btn btn-modern" onClick={() => window.location.href = '/login'}>
              Go to Login
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fade-in" style={{ minHeight: '100vh', background: 'var(--bg-primary)', padding: 'var(--spacing-xl) 0' }}>
      <div className="container" style={{ maxWidth: 800 }}>
        {/* Header Section */}
        <div className="text-center mb-5">
          <div className="modern-card p-4 mb-4" style={{ maxWidth: '200px', margin: '0 auto' }}>
            <div className="d-inline-block p-4 rounded-circle bg-gradient-primary text-white mb-3 float-animation" style={{ fontSize: '3rem' }}>
              <FaUser />
            </div>
          </div>
          <h1 className="gradient-text mb-2">My Profile</h1>
          <p className="text-muted">Manage your account information and preferences</p>
        </div>

        {/* Profile Information */}
        <div className="row g-4">
          {/* Personal Information Card */}
          <div className="col-lg-8">
            <div className="modern-card">
              <div className="card-body p-4">
                <div className="d-flex align-items-center mb-4">
                  <FaUser className="me-3 text-primary" size={24} />
                  <h3 className="mb-0">Personal Information</h3>
                </div>

                <div className="row g-4">
                  <div className="col-md-6">
                    <div className="mb-3">
                      <label className="form-label fw-bold text-muted d-flex align-items-center">
                        <FaUser className="me-2" />
                        Username
                      </label>
                      <div className="form-control-plaintext fw-bold" style={{ fontSize: '1.1rem', color: 'var(--text-primary)' }}>
                        {user.username || 'Not available'}
                      </div>
                    </div>
                  </div>

                  <div className="col-md-6">
                    <div className="mb-3">
                      <label className="form-label fw-bold text-muted d-flex align-items-center">
                        <FaShieldAlt className="me-2" />
                        Account Role
                      </label>
                      <div className="form-control-plaintext">
                        <span className={`badge ${user.role === 'admin' ? 'bg-danger' : 'bg-success'} glow-effect`} style={{ fontSize: '1rem', padding: 'var(--spacing-sm) var(--spacing-md)' }}>
                          <span className="status-indicator status-online"></span>
                          {user.role === 'admin' ? 'Administrator' : 'Customer'}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="col-md-6">
                    <div className="mb-3">
                      <label className="form-label fw-bold text-muted d-flex align-items-center">
                        <FaEnvelope className="me-2" />
                        Email
                      </label>
                      <div className="form-control-plaintext" style={{ color: 'var(--text-secondary)' }}>
                        {user.email || 'Not provided'}
                      </div>
                    </div>
                  </div>

                  <div className="col-md-6">
                    <div className="mb-3">
                      <label className="form-label fw-bold text-muted d-flex align-items-center">
                        <FaPhone className="me-2" />
                        Phone
                      </label>
                      <div className="form-control-plaintext" style={{ color: 'var(--text-secondary)' }}>
                        {user.phone || 'Not provided'}
                      </div>
                    </div>
                  </div>

                  <div className="col-12">
                    <div className="mb-3">
                      <label className="form-label fw-bold text-muted d-flex align-items-center">
                        <FaMapMarkerAlt className="me-2" />
                        Address
                      </label>
                      <div className="form-control-plaintext" style={{ color: 'var(--text-secondary)' }}>
                        {user.address || 'Not provided'}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Account Stats Card */}
          <div className="col-lg-4">
            <div className="modern-card">
              <div className="card-body p-4">
                <h4 className="mb-4 text-primary">Account Statistics</h4>
                
                <div className="mb-4">
                  <div className="d-flex justify-content-between align-items-center mb-2">
                    <span className="text-muted">Member Since</span>
                    <FaCalendarAlt className="text-primary" />
                  </div>
                  <div className="fw-bold" style={{ color: 'var(--text-primary)' }}>
                    {user.created_at ? new Date(user.created_at).toLocaleDateString() : 'Unknown'}
                  </div>
                </div>

                <div className="mb-4">
                  <div className="d-flex justify-content-between align-items-center mb-2">
                    <span className="text-muted">Account Status</span>
                    <span className="status-indicator status-online"></span>
                  </div>
                  <div className="fw-bold text-success">Active</div>
                </div>

                <div className="mb-4">
                  <div className="d-flex justify-content-between align-items-center mb-2">
                    <span className="text-muted">Last Login</span>
                  </div>
                  <div className="fw-bold" style={{ color: 'var(--text-primary)' }}>
                    {user.last_login ? new Date(user.last_login).toLocaleString() : 'Unknown'}
                  </div>
                </div>

                <button className="btn btn-modern w-100">
                  Edit Profile
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="row mt-5">
          <div className="col-12">
            <div className="modern-card">
              <div className="card-body p-4">
                <h4 className="mb-4 text-primary">Quick Actions</h4>
                <div className="row g-3">
                  <div className="col-md-3">
                    <button className="btn btn-outline-primary w-100" style={{ borderColor: 'var(--primary-color)', color: 'var(--primary-color)' }}>
                      <FaUser className="me-2" />
                      Update Profile
                    </button>
                  </div>
                  <div className="col-md-3">
                    <button className="btn btn-outline-secondary w-100" style={{ borderColor: 'var(--secondary-color)', color: 'var(--secondary-color)' }}>
                      <FaShieldAlt className="me-2" />
                      Security Settings
                    </button>
                  </div>
                  <div className="col-md-3">
                    <button className="btn btn-outline-info w-100" style={{ borderColor: 'var(--info-color)', color: 'var(--info-color)' }}>
                      <FaEnvelope className="me-2" />
                      Contact Support
                    </button>
                  </div>
                  <div className="col-md-3">
                    <button className="btn btn-outline-warning w-100" style={{ borderColor: 'var(--warning-color)', color: 'var(--warning-color)' }}>
                      <FaCalendarAlt className="me-2" />
                      View History
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile; 