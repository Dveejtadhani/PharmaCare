import React, { useState, useEffect } from 'react';
import cartThemeImg from '../images/2.webp';
import { useNavigate } from 'react-router-dom';


const Cart = () => {
  const [cart, setCart] = useState(() => {
    try {
      const stored = localStorage.getItem('cart');
      const parsed = stored ? JSON.parse(stored) : [];
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  });
  const [customerName, setCustomerName] = useState('');
  const [orderStatus, setOrderStatus] = useState(null); // { type: 'success'|'error', message: string }
  const navigate = useNavigate();

  // Sync cart to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('cart', JSON.stringify(cart));
  }, [cart]);

  const handleQty = (id, delta) => {
    setCart(cart => cart.map(item =>
      item.id === id ? { ...item, qty: Math.max(1, item.qty + delta) } : item
    ));
  };

  const handleRemove = (id) => {
    setCart(cart => cart.filter(item => item.id !== id));
  };

  const handleCheckout = async () => {
    setOrderStatus(null);
    if (!customerName.trim()) {
      setOrderStatus({ type: 'error', message: 'Please enter your name.' });
      return;
    }
    if (cart.length === 0) {
      setOrderStatus({ type: 'error', message: 'Your cart is empty.' });
      return;
    }
    try {
      const response = await fetch('http://localhost:8000/api/customer-orders/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customer_name: customerName,
          items: cart.map(item => ({ medicine_id: item.id, quantity: item.qty }))
        })
      });
      const data = await response.json();
      if (response.ok) {
        setOrderStatus({ type: 'success', message: 'Order placed successfully! Order ID: ' + data.order_id });
        setCart([]); // Clear cart on success
        setTimeout(() => navigate('/customer/orders'), 1200); // Redirect after 1.2s
      } else {
        setOrderStatus({ type: 'error', message: data.error || 'Order failed.' });
      }
    } catch (err) {
      setOrderStatus({ type: 'error', message: 'Network error. Please try again.' });
    }
  };

  const subtotal = cart.reduce((sum, item) => sum + item.price * item.qty, 0);
  const total = subtotal;

  return (
    <div style={{
      minHeight: '100vh',
      background: 'transparent',
      padding: '40px 0',
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'flex-start',
    }}>
      <div style={{
        background: '#fff',
        borderRadius: 24,
        boxShadow: '0 4px 32px #0002',
        padding: 0,
        maxWidth: 1100,
        width: '95%',
        display: 'flex',
        gap: 0,
        overflow: 'hidden',
      }}>
        {/* Left: Cart Items with background accent */}
        <div style={{
          flex: 2,
          position: 'relative',
          padding: '48px 32px 32px 32px',
          background: 'linear-gradient(120deg, #e0e7ff 60%, #f0fff0 100%)',
          minHeight: 500,
        }}>
          {/* Faded cart image accent */}
         
          <div style={{ position: 'relative', zIndex: 1 }}>
            <h2 style={{ fontWeight: 800, fontSize: 32, marginBottom: 32, letterSpacing: 1, color: '#22223b' }}>🛒 My Shopping Cart</h2>
            {orderStatus && (
              <div style={{
                marginBottom: 16,
                padding: 12,
                borderRadius: 8,
                background: orderStatus.type === 'success' ? '#d1fae5' : '#fee2e2',
                color: orderStatus.type === 'success' ? '#065f46' : '#991b1b',
                fontWeight: 600,
              }}>
                {orderStatus.message}
              </div>
            )}
            <table style={{ width: '100%', borderCollapse: 'separate', borderSpacing: 0, marginBottom: 24 }}>
              <thead>
                <tr style={{ borderBottom: '2px solid #e5e7eb' }}>
                  <th style={{ textAlign: 'left', padding: 12, fontWeight: 600, color: '#6366f1' }}>Product</th>
                  <th style={{ textAlign: 'left', padding: 12, fontWeight: 600, color: '#6366f1' }}>Name</th>
                  <th style={{ textAlign: 'center', padding: 12, fontWeight: 600, color: '#6366f1' }}>Quantity</th>
                  <th style={{ textAlign: 'right', padding: 12, fontWeight: 600, color: '#6366f1' }}>Price</th>
                  <th style={{ textAlign: 'right', padding: 12 }}></th>
                </tr>
              </thead>
              <tbody>
                {cart.length === 0 ? (
                  <tr>
                    <td colSpan={5} style={{ textAlign: 'center', color: '#888', padding: 32, fontSize: 18 }}>
                      Your cart is empty.
                    </td>
                  </tr>
                ) : (
                  cart.map(item => item && item.id && (
                    <tr key={item.id} style={{ borderBottom: '1px solid #e5e7eb', background: '#f8fafc', transition: 'background 0.2s' }}>
                      <td style={{ padding: 12 }}>
                        <img src={item.image} alt={item.name} style={{ width: 56, height: 72, objectFit: 'contain', borderRadius: 12, boxShadow: '0 2px 8px #0001' }} />
                      </td>
                      <td style={{ padding: 12, verticalAlign: 'middle', fontWeight: 600, color: '#22223b' }}>{item.name}</td>
                      <td style={{ padding: 12, verticalAlign: 'middle', textAlign: 'center' }}>
                        <button onClick={() => handleQty(item.id, -1)} style={{ margin: '0 6px', border: 'none', background: '#e0e7ff', borderRadius: 6, width: 28, height: 28, fontWeight: 700, fontSize: 18, color: '#6366f1', cursor: 'pointer', transition: 'background 0.2s' }}
                          onMouseOver={e => e.currentTarget.style.background = '#6366f1'}
                          onMouseOut={e => e.currentTarget.style.background = '#e0e7ff'}>-</button>
                        <span style={{ fontWeight: 600, fontSize: 16, margin: '0 8px', color: '#22223b'}}>{item.qty}</span>
                        <button onClick={() => handleQty(item.id, 1)} style={{ margin: '0 6px', border: 'none', background: '#e0e7ff', borderRadius: 6, width: 28, height: 28, fontWeight: 700, fontSize: 18, color: '#6366f1', cursor: 'pointer', transition: 'background 0.2s' }}
                          onMouseOver={e => e.currentTarget.style.background = '#6366f1'}
                          onMouseOut={e => e.currentTarget.style.background = '#e0e7ff'}>+</button>
                      </td>
                      <td style={{ padding: 12, verticalAlign: 'middle', textAlign: 'right', fontWeight: 600, color: '#22223b' }}>
                        ${item.price * item.qty}
                      </td>
                      <td style={{ padding: 12, verticalAlign: 'middle', textAlign: 'right' }}>
                        <button onClick={() => handleRemove(item.id)} style={{ border: 'none', background: 'none', color: '#dc2626', fontSize: 20, cursor: 'pointer', transition: 'color 0.2s' }}
                          onMouseOver={e => e.currentTarget.style.color = '#b91c1c'}
                          onMouseOut={e => e.currentTarget.style.color = '#dc2626'} title="Remove">🗑️</button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
            {/* Customer Name Input */}
            <div style={{ marginBottom: 16 }}>
              <label style={{ fontWeight: 600, color: '#22223b', marginRight: 8 }}>Your Name:</label>
              <input
                type="text"
                value={customerName}
                onChange={e => setCustomerName(e.target.value)}
                placeholder="Enter your name"
                style={{ padding: 8, borderRadius: 6, border: '1px solid #e5e7eb', fontSize: 15, width: 220 }}
              />
            </div>
          </div>
        </div>
        {/* Right: Summary */}
        <div style={{
          flex: 1,
          background: '#f8f9fa',
          borderRadius: '0 24px 24px 0',
          padding: 40,
          minWidth: 320,
          maxWidth: 360,
          boxShadow: '0 1px 6px #0001',
          display: 'flex',
          flexDirection: 'column',
          gap: 16,
          alignItems: 'stretch',
        }}>
          <h3 style={{ fontWeight: 800, fontSize: 26, marginBottom: 24, color: '#22223b' }}>Summary</h3>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8, fontWeight: 600 }}>
            <span style={{color: '#22223b'}}>ITEMS {cart.length}</span>
            <span style={{color: '#22223b'}}>${subtotal.toFixed(2)}</span>
          </div>
          <div style={{ borderTop: '1px solid #e5e7eb', margin: '18px 0' }}></div>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4, fontWeight: 500 }}>
            <span style={{color: '#22223b'}}>SUB TOTAL</span>
            <span style={{color: '#22223b'}}>${subtotal.toFixed(2)}</span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 800, fontSize: 20, marginBottom: 18, color: '#22223b' }}>
            <span style={{color: '#22223b'}}>TOTAL PRICE</span>
            <span>${total.toFixed(2)}</span>
          </div>
          <button style={{ background: 'linear-gradient(90deg, #3b8070 60%, #6366f1 100%)', color: '#fff', border: 'none', borderRadius: 8, padding: '14px 0', fontWeight: 700, fontSize: 18, cursor: 'pointer', boxShadow: '0 2px 8px #0001', transition: 'background 0.2s' }}
            onMouseOver={e => e.currentTarget.style.background = 'linear-gradient(90deg, #6366f1 60%, #3b8070 100%)'}
            onMouseOut={e => e.currentTarget.style.background = 'linear-gradient(90deg, #3b8070 60%, #6366f1 100%)'}
            onClick={handleCheckout}
          >
            Checkout
          </button>
        </div>
      </div>
    </div>
  );
};

export default Cart;
