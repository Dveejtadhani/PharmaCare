import React, { useState, useEffect } from "react";

const CustomerOrders = () => {
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = () => {
    fetch("http://localhost:8000/api/customer-orders/")
      .then(res => res.json())
      .then(data => setOrders(data));
  };

  const markAsSuccessful = async (orderId, orderTotal) => {
    await fetch(`http://localhost:8000/api/customer-orders/${orderId}/`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: 'successful' })
    });
    
    // Update revenue when order is completed
    await fetch('http://localhost:8000/api/update-revenue/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ amount: orderTotal })
    });
    
    // Trigger dashboard refresh to update pending orders count
    window.dispatchEvent(new CustomEvent('dashboardRefresh'));
    
    fetchOrders();
  };

  return (
    <div style={{ position: 'relative', minHeight: '100vh', overflow: 'hidden', background: 'linear-gradient(135deg, #e0e7ff 0%, #f0fff0 100%)' }}>
      {/* SVG Blobs for background decoration */}
      <svg style={{ position: 'absolute', top: -80, left: -80, zIndex: 0, opacity: 0.35 }} width="320" height="320" viewBox="0 0 320 320" fill="none" xmlns="http://www.w3.org/2000/svg">
        <ellipse cx="160" cy="160" rx="160" ry="120" fill="#a5b4fc" />
      </svg>
      <svg style={{ position: 'absolute', bottom: -100, right: -100, zIndex: 0, opacity: 0.25 }} width="340" height="340" viewBox="0 0 340 340" fill="none" xmlns="http://www.w3.org/2000/svg">
        <ellipse cx="170" cy="170" rx="170" ry="130" fill="#6ee7b7" />
      </svg>
      {/* Customer Orders List */}
      <div className="container-fluid py-4 position-relative" style={{ zIndex: 1, paddingLeft: 32, paddingRight: 32 }}>
        <h4 className="fw-bold mb-3" style={{ color: 'black' }}>All Customer Orders</h4>
        {orders.length === 0 ? (
          <div style={{color: 'black'}}>No orders found.</div>
        ) : (
          <div className="row g-4">
            {orders.map(order => (
              <div className="col-12 col-md-6 col-lg-4" key={order.id}>
                <div className="card shadow border-0 rounded-4 h-100">
                  <div className="card-body">
                    <div className="d-flex justify-content-between align-items-center mb-2">
                      <span className="fw-semibold" style={{color: 'white'}}>Order #{order.id}</span>
                      <span style={{ color: order.status === 'pending' ? '#f59e42' : '#16a34a', fontWeight: 600 }}>
                        {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                      </span>
                      {order.status === 'pending' && (
                        <button
                          style={{ marginLeft: 12, background: '#16a34a', color: '#fff', border: 'none', borderRadius: 6, padding: '4px 12px', fontWeight: 600, cursor: 'pointer' }}
                          onClick={() => markAsSuccessful(order.id, order.total_amount)}
                        >
                          Mark as Successful
                        </button>
                      )}
                    </div>
                    <div style={{color: 'white'}}><b>Customer:</b> {order.customer_name}</div>
                    <div style={{color: 'white'}}><b>Total:</b> ₹{order.total_amount}</div>
                    <div style={{color: 'white'}}><b>Placed on:</b> {order.created_at}</div>
                    <div className="mt-2">
                      <b style={{color: 'white'}}>Items:</b>
                      <ul className="mb-0" style={{color: 'white'}}>
                        {order.items && order.items.map(item => (
                          <li key={item.medicine_id}>
                            {item.medicine_name} (Qty: {item.quantity}, ₹{item.unit_price})
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default CustomerOrders;
