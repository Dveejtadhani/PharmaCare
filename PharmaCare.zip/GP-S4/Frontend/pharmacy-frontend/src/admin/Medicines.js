// src/components/Medicines.js
import React, { useEffect, useState } from "react";
import {
  getMedicines,
  createMedicine,
  updateMedicine,
  deleteMedicine,
} from "../api/api";
import { FaPills, FaEdit, FaTrash } from 'react-icons/fa';

const Medicines = () => {
  const [medicines, setMedicines] = useState([]);
  const [formData, setFormData] = useState({
    name: "",
    brand: "",
    price: "",
    stock_quantity: "",
    min_stock_level: "",
  });
  const [editingId, setEditingId] = useState(null);

  useEffect(() => {
    loadMedicines();
  }, []);

  const loadMedicines = async () => {
    const data = await getMedicines();
    setMedicines(data);
  };

  const handleChange = (e) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (editingId) {
      await updateMedicine(editingId, formData);
    } else {
      await createMedicine(formData);
    }
    setFormData({
      name: "",
      brand: "",
      price: "",
      stock_quantity: "",
      min_stock_level: "",
    });
    setEditingId(null);
    loadMedicines();
  };

  const handleEdit = (medicine) => {
    setFormData(medicine);
    setEditingId(medicine.id);
  };

  const handleDelete = async (id) => {
    if (window.confirm("Are you sure you want to delete this medicine?")) {
      await deleteMedicine(id);
      loadMedicines();
    }
  };

  return (
    <div style={{ position: 'relative', minHeight: '100vh', overflow: 'hidden', background: 'linear-gradient(135deg, #e0e7ff 0%, #f0fff0 100%)' }}>
      {/* SVG Blobs for background decoration */}
      <svg style={{ position: 'absolute', top: -80, left: -80, zIndex: 0, opacity: 0.35 }} width="320" height="320" viewBox="0 0 320 320" fill="none" xmlns="http://www.w3.org/2000/svg">
        <ellipse cx="160" cy="160" rx="160" ry="120" fill="#a5b4fc" />
      </svg>
      <svg style={{ position: 'absolute', bottom: -100, right: -100, zIndex: 0, opacity: 0.25 }} width="340" height="340" viewBox="0 0 340 340" fill="none" xmlns="http://www.w3.org/2000/svg">
        <ellipse cx="170" cy="170" rx="170" ry="130" fill="#6ee7b7" />
      </svg>
      <div style={{ position: 'relative', zIndex: 1 }}>
        <div className="container mt-4">
          <div className="d-flex align-items-center mb-4" style={{ gap: 12 }}>
            <FaPills size={32} className="text-primary" />
            <h3 className="mb-0 fw-bold" style={{ letterSpacing: 1, color: '#22223b' }}>Medicines</h3>
          </div>

          <div className="row g-4 mb-4">
            <div className="col-12 col-lg-5">
              <div className="card shadow border-0 rounded-4 h-100">
                <div className="card-body">
                  <h5 className="card-title mb-3 fw-semibold text-primary">{editingId ? 'Edit Medicine' : 'Add Medicine'}</h5>
                  <form onSubmit={handleSubmit} className="row g-2">
                    <div className="col-12 col-md-6">
                      <input
                        type="text"
                        name="name"
                        placeholder="Name"
                        value={formData.name}
                        onChange={handleChange}
                        className="form-control"
                        required
                      />
                    </div>
                    <div className="col-12 col-md-6">
                      <input
                        type="text"
                        name="brand"
                        placeholder="Brand"
                        value={formData.brand}
                        onChange={handleChange}
                        className="form-control"
                        required
                      />
                    </div>
                    <div className="col-12 col-md-4">
                      <input
                        type="number"
                        name="price"
                        placeholder="Price"
                        value={formData.price}
                        onChange={handleChange}
                        className="form-control"
                        required
                      />
                    </div>
                    <div className="col-12 col-md-4">
                      <input
                        type="number"
                        name="stock_quantity"
                        placeholder="Stock Qty"
                        value={formData.stock_quantity}
                        onChange={handleChange}
                        className="form-control"
                        required
                      />
                    </div>
                    <div className="col-12 col-md-4">
                      <input
                        type="number"
                        name="min_stock_level"
                        placeholder="Min Stock"
                        value={formData.min_stock_level}
                        onChange={handleChange}
                        className="form-control"
                        required
                      />
                    </div>
                    <div className="col-12">
                      <button type="submit" className="btn btn-primary w-100 rounded-pill mt-2">
                        {editingId ? 'Update' : 'Add'} Medicine
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
            <div className="col-12 col-lg-7">
              <div className="card shadow border-0 rounded-4 h-100">
                <div className="card-body">
                  <h5 className="card-title mb-3 fw-semibold text-primary">Medicine List</h5>
                  <div className="table-responsive">
                    <table className="table table-bordered table-striped align-middle mb-0">
                      <thead className="table-light sticky-top">
                        <tr>
                          <th>Name</th>
                          <th>Brand</th>
                          <th>Price</th>
                          <th>Stock Qty</th>
                          <th>Min Stock</th>
                          <th>Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {medicines.map((m) => (
                          <tr key={m.id}>
                            <td>{m.name}</td>
                            <td>{m.brand}</td>
                            <td>₹{m.price}</td>
                            <td>{m.stock_quantity}</td>
                            <td>{m.min_stock_level}</td>
                            <td>
                              <button
                                className="btn btn-sm btn-outline-primary rounded-circle me-2"
                                title="Edit"
                                onClick={() => handleEdit(m)}
                              >
                                <FaEdit />
                              </button>
                              <button
                                className="btn btn-sm btn-outline-danger rounded-circle"
                                title="Delete"
                                onClick={() => handleDelete(m.id)}
                              >
                                <FaTrash />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Medicines;
