import React, { useEffect, useState } from "react";
import { FaTruckLoading } from 'react-icons/fa';

const StockOrders = () => {
  const [orders, setOrders] = useState([]);
  const [medicines, setMedicines] = useState([]);
  const [form, setForm] = useState({
    medicine_id: "",
    quantity: "",
    unit_price: "",
    supplier: "",
    status: "pending",
  });

  useEffect(() => {
    fetchOrders();
    fetchMedicines();
  }, []);

  const fetchOrders = async () => {
    const res = await fetch("http://localhost:8000/api/stock-orders/");
    const data = await res.json();
    setOrders(data);
  };

  const fetchMedicines = async () => {
    const res = await fetch("http://localhost:8000/api/medicines/");
    const data = await res.json();
    setMedicines(data);
  };

  const handleChange = (e) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await fetch("http://localhost:8000/api/stock-orders/", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    setForm({
      medicine_id: "",
      quantity: "",
      unit_price: "",
      supplier: "",
      status: "pending",
    });
    fetchOrders();
  };

  const markAsArrived = async (id) => {
    await fetch(`http://localhost:8000/api/stock-orders/${id}/`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: "arrived" }),
    });
    fetchOrders();
  };

  const getStockStatus = (currentStock, minStock) => {
    if (currentStock <= minStock) return { text: "Low Stock", color: "text-danger" };
    if (currentStock <= minStock * 1.5) return { text: "Medium Stock", color: "text-warning" };
    return { text: "Good Stock", color: "text-success" };
  };

  return (
    <div style={{ position: 'relative', minHeight: '100vh', overflow: 'hidden', background: 'linear-gradient(135deg, #e0e7ff 0%, #f0fff0 100%)' }}>
      {/* SVG Blobs for background decoration */}
      <svg style={{ position: 'absolute', top: -80, left: -80, zIndex: 0, opacity: 0.35 }} width="320" height="320" viewBox="0 0 320 320" fill="none" xmlns="http://www.w3.org/2000/svg">
        <ellipse cx="160" cy="160" rx="160" ry="120" fill="#a5b4fc" />
      </svg>
      <svg style={{ position: 'absolute', bottom: -100, right: -100, zIndex: 0, opacity: 0.25 }} width="340" height="340" viewBox="0 0 340 340" fill="none" xmlns="http://www.w3.org/2000/svg">
        <ellipse cx="170" cy="170" rx="170" ry="130" fill="#6ee7b7" />
      </svg>
      <div className="container-fluid py-4 position-relative" style={{ zIndex: 1, paddingLeft: 32, paddingRight: 32 }}>
        <div className="d-flex align-items-center mb-4" style={{ gap: 12 }}>
          <FaTruckLoading size={32} className="text-success" />
          <h3 className="mb-0 fw-bold" style={{ letterSpacing: 1, color: '#22223b' }}>Stock Orders</h3>
        </div>
        <div className="row g-4 mb-4">
          <div className="col-12 col-lg-5">
            <div className="card shadow border-0 rounded-4 h-100">
              <div className="card-body">
                <h5 className="card-title mb-3 fw-semibold text-success">Create Stock Order</h5>
                <form onSubmit={handleSubmit} className="row g-2">
                  <div className="col-12 col-md-6">
                    <select
                      name="medicine_id"
                      value={form.medicine_id}
                      onChange={handleChange}
                      className="form-select"
                      required
                    >
                      <option value="">Select Medicine</option>
                      {medicines.map((m) => (
                        <option key={m.id} value={m.id}>
                          {m.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="col-12 col-md-6">
                    <input
                      type="number"
                      name="quantity"
                      value={form.quantity}
                      onChange={handleChange}
                      placeholder="Quantity"
                      className="form-control"
                      required
                    />
                  </div>
                  <div className="col-12 col-md-6">
                    <input
                      type="number"
                      name="unit_price"
                      value={form.unit_price}
                      onChange={handleChange}
                      placeholder="Unit Price"
                      className="form-control"
                      required
                    />
                  </div>
                  <div className="col-12 col-md-6">
                    <input
                      type="text"
                      name="supplier"
                      value={form.supplier}
                      onChange={handleChange}
                      placeholder="Supplier Name"
                      className="form-control"
                      required
                    />
                  </div>
                  <div className="col-12">
                    <button type="submit" className="btn btn-success w-100 rounded-pill mt-2">
                      Create Order
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
          <div className="col-12 col-lg-7">
            <div className="card shadow border-0 rounded-4 h-100">
              <div className="card-body">
                <h5 className="card-title mb-3 fw-semibold text-success">Order List</h5>
                <div className="table-responsive">
                  <table className="table table-bordered table-striped align-middle mb-0">
                    <thead className="table-light sticky-top">
                      <tr>
                        <th>Medicine</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Supplier</th>
                        <th>Status</th>
                        <th>Date</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {orders.map((o) => (
                        <tr key={o.id}>
                          <td>{o.medicine_name}</td>
                          <td>{o.quantity}</td>
                          <td>₹{o.unit_price}</td>
                          <td>{o.supplier}</td>
                          <td>{o.status}</td>
                          <td>{o.created_at}</td>
                          <td>
                            {o.status === "pending" && (
                              <button
                                className="btn btn-sm btn-primary rounded-pill"
                                onClick={() => markAsArrived(o.id)}
                              >
                                Mark Arrived
                              </button>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Current Stock Levels */}
      <div className="container-fluid py-4 position-relative" style={{ zIndex: 1, paddingLeft: 32, paddingRight: 32 }}>
        <h4 className="fw-bold mb-3" style={{ color: '#2563eb' }}>Current Stock Levels</h4>
        <div className="row g-4">
          {medicines.map(medicine => {
            const stockStatus = getStockStatus(medicine.stock_quantity, medicine.min_stock_level);
            return (
              <div className="col-12 col-md-6 col-lg-4" key={medicine.id}>
                <div className="card shadow border-0 rounded-4 h-100">
                  <div className="card-body">
                    <div className="d-flex justify-content-between align-items-center mb-2">
                      <h6 className="fw-semibold mb-0" style={{color: 'white'}}>{medicine.name}</h6>
                      <span className={`badge ${stockStatus.color === 'text-danger' ? 'bg-danger' : stockStatus.color === 'text-warning' ? 'bg-warning' : 'bg-success'}`}>
                        {stockStatus.text}
                      </span>
                    </div>
                    <div style={{color: 'white'}}><b>Brand:</b> {medicine.brand}</div>
                    <div style={{color: 'white'}}><b>Current Stock:</b> {medicine.stock_quantity}</div>
                    <div style={{color: 'white'}}><b>Min Stock Level:</b> {medicine.min_stock_level}</div>
                    <div style={{color: 'white'}}><b>Price:</b> ₹{medicine.price}</div>
                    <div className={`mt-2 ${stockStatus.color}`}>
                      <b>Status:</b> {stockStatus.text}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default StockOrders;
