import React, { useEffect, useState } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { FaBoxOpen, FaClipboardList, FaRupeeSign } from "react-icons/fa";
import logo from '../logo.svg'; // Placeholder logo, replace with your own if needed

const mockRevenueData = [
  { date: "Mon", revenue: 1200 },
  { date: "Tue", revenue: 2100 },
  { date: "Wed", revenue: 800 },
  { date: "Thu", revenue: 1600 },
  { date: "Fri", revenue: 900 },
  { date: "Sat", revenue: 1700 },
  { date: "Sun", revenue: 2200 },
];

const Dashboard = () => {
  const [lowStock, setLowStock] = useState([]);
  const [pendingOrders, setPendingOrders] = useState([]);
  const [todayRevenue, setTodayRevenue] = useState(0);
  // Optionally, fetch revenue data from backend in future
  const [revenueData] = useState(mockRevenueData);

  useEffect(() => {
    fetch("http://localhost:8000/api/dashboard/")
      .then((res) => res.json())
      .then((data) => {
        setLowStock(data.low_stock);
        setPendingOrders(data.pending_orders);
        setTodayRevenue(data.today_revenue);
      });
  }, []);

  return (
    <div style={{ position: 'relative', minHeight: '100vh', overflow: 'hidden', background: 'linear-gradient(135deg, #e0e7ff 0%, #f0fff0 100%)', }}>
      {/* SVG Blobs for background decoration */}
      <svg style={{ position: 'absolute', top: -80, left: -80, zIndex: 0, opacity: 0.35 }} width="320" height="320" viewBox="0 0 320 320" fill="none" xmlns="http://www.w3.org/2000/svg">
        <ellipse cx="160" cy="160" rx="160" ry="120" fill="#a5b4fc" />
      </svg>
      <svg style={{ position: 'absolute', bottom: -100, right: -100, zIndex: 0, opacity: 0.25 }} width="340" height="340" viewBox="0 0 340 340" fill="none" xmlns="http://www.w3.org/2000/svg">
        <ellipse cx="170" cy="170" rx="170" ry="130" fill="#6ee7b7" />
      </svg>
      <div className="container-fluid py-4 position-relative" style={{ zIndex: 1, paddingLeft: 32, paddingRight: 32 }}>
        <div className="d-flex align-items-center mb-4" style={{ gap: 16 }}>
          <h2 className="mb-0 fw-bold" style={{ marginTop: 20, fontSize: 32, letterSpacing: 1, color: '#22223b' }}>Dashboard</h2>
        </div>
        <hr className="mb-4" />
        <div className="row g-4 mb-4">
          <div className="col-md-4">
            <div className="card shadow border-0 rounded-4" style={{ background: '#e0f7fa' }}>
              <div className="card-body d-flex align-items-center gap-3">
                <FaBoxOpen size={36} className="text-info" />
                <div>
                  <h6 className="card-title mb-1 text-secondary">Low Stock Medicines</h6>
                  <p className="card-text fs-4 fw-semibold mb-0" style={{color: '#22223b'}}>{lowStock.length}</p>
                </div>
              </div>
            </div>
          </div>
          <div className="col-md-4">
            <div className="card shadow border-0 rounded-4" style={{ background: '#ffe0e6' }}>
              <div className="card-body d-flex align-items-center gap-3">
                <FaClipboardList size={36} className="text-danger" />
                <div>
                  <h6 className="card-title mb-1 text-secondary">Pending Stock Orders</h6>
                  <p className="card-text fs-4 fw-semibold mb-0" style={{color: '#22223b'}}>{pendingOrders.length}</p>
                </div>
              </div>
            </div>
          </div>
          <div className="col-md-4">
            <div className="card shadow border-0 rounded-4" style={{ background: '#e0ffe0' }}>
              <div className="card-body d-flex align-items-center gap-3">
                <FaRupeeSign size={36} className="text-success" />
                <div>
                  <h6 className="card-title mb-1 text-secondary">Today's Revenue</h6>
                  <p className="card-text fs-4 fw-semibold mb-0" style={{color: '#22223b'}}>₹{todayRevenue}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="row g-4 mb-4">
          <div className="col-12 col-lg-6">
            <div className="card shadow border-0 rounded-4 h-100">
              <div className="card-body">
                <h6 className="card-title mb-3 fw-bold" style={{ background: '#f0f0f0', padding: '8px 12px', borderRadius: 8 }}>Revenue This Week</h6>
                <ResponsiveContainer width="100%" height={220}>
                  <BarChart data={revenueData} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date"/>
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="revenue" fill="#198754" radius={[6, 6, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
          <div className="col-12 col-lg-6">
            <div className="card shadow border-0 rounded-4 h-100">
              <div className="card-body">
                <h6 className="card-title mb-3 fw-bold" style={{ background: '#f0f0f0', padding: '8px 12px', borderRadius: 8 }}>Low Stock Medicines</h6>
                {lowStock.length > 0 ? (
                  <div className="table-responsive">
                    <table className="table table-bordered align-middle mb-0">
                      <thead className="table-light">
                        <tr>
                          <th>Name</th>
                          <th>Brand</th>
                          <th>Stock</th>
                          <th>Minimum Required</th>
                        </tr>
                      </thead>
                      <tbody>
                        {lowStock.map((med) => (
                          <tr key={med.id} className={med.stock_quantity < med.min_stock_level ? "table-danger" : ""}>
                            <td>{med.name}</td>
                            <td>{med.brand}</td>
                            <td>{med.stock_quantity}</td>
                            <td>{med.min_stock_level}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <p className="text-muted mb-0">No medicines are low on stock.</p>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;