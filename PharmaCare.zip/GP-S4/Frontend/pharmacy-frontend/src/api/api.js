const BASE_URL = "http://localhost:8000/api";

// =================== MEDICINES ===================

// GET all medicines
export const getMedicines = async () => {
  const res = await fetch(`${BASE_URL}/medicines/`);
  return await res.json();
};

// CREATE a new medicine
export const createMedicine = async (data) => {
  const res = await fetch(`${BASE_URL}/medicines/`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  return await res.json();
};

// UPDATE a medicine
export const updateMedicine = async (id, data) => {
  const res = await fetch(`${BASE_URL}/medicines/${id}/`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  return await res.json();
};

// DELETE a medicine
export const deleteMedicine = async (id) => {
  const res = await fetch(`${BASE_URL}/medicines/${id}/`, {
    method: "DELETE",
  });
  return await res.json();
};

// =================== STOCK ORDERS ===================

// GET all stock orders
export const getStockOrders = async () => {
  const res = await fetch(`${BASE_URL}/stock-orders/`);
  return await res.json();
};

// CREATE a new stock order
export const createStockOrder = async (data) => {
  const res = await fetch(`${BASE_URL}/stock-orders/`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  return await res.json();
};

// MARK stock order as "arrived"
export const markStockOrderArrived = async (id) => {
  const res = await fetch(`${BASE_URL}/stock-orders/${id}/`, {
    method: "PUT",
  });
  return await res.json();
};

// =================== CUSTOMER ORDERS ===================

// GET all customer orders
export const getCustomerOrders = async () => {
  const res = await fetch(`${BASE_URL}/customer-orders/`);
  return await res.json();
};

// CREATE a new customer order
export const createCustomerOrder = async (data) => {
  const res = await fetch(`${BASE_URL}/customer-orders/`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  return await res.json();
};

// =================== DASHBOARD ===================

// GET dashboard stats (low stock, revenue, pending orders)
export const getDashboardStats = async () => {
  const res = await fetch(`${BASE_URL}/dashboard/`);
  return await res.json();
};
