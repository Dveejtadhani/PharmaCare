import React, { useState } from "react";
import { FaUser, FaLock, FaUserShield, FaEye, FaEyeSlash, FaUserPlus, FaEnvelope } from 'react-icons/fa';
import { Link } from 'react-router-dom';

const Signup = () => {
  const [form, setForm] = useState({ 
    username: "", 
    password: "", 
    confirmPassword: "",
    email: "",
    role: "customer" 
  });
  const [error, setError] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const validateForm = () => {
    if (form.password !== form.confirmPassword) {
      setError("Passwords do not match");
      return false;
    }
    if (form.password.length < 6) {
      setError("Password must be at least 6 characters long");
      return false;
    }
    if (!form.username.trim()) {
      setError("Username is required");
      return false;
    }
    return true;
  };

  const handleSignup = async () => {
    setError("");
    
    if (!validateForm()) {
      return;
    }

    setIsLoading(true);
    
    try {
      const res = await fetch("http://localhost:8000/api/signup/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: form.username,
          password: form.password,
          email: form.email,
          role: form.role
        }),
      });
      const data = await res.json();
      
      if (res.ok) {
        // Auto-login after signup
        const loginRes = await fetch("http://localhost:8000/api/login/", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            username: form.username,
            password: form.password,
            role: form.role
          }),
        });
        const loginData = await loginRes.json();
        
        if (loginRes.ok) {
          localStorage.setItem("user", JSON.stringify(loginData));
          if (form.role === "admin") {
            window.location.href = "/dashboard";
          } else {
            window.location.href = "/customer";
          }
        } else {
          setError(loginData.error || "Auto-login failed. Please login manually.");
        }
      } else {
        setError(data.error || "Signup failed");
      }
    } catch (err) {
      setError("Network error. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fade-in" style={{ 
      position: 'relative', 
      minHeight: '100vh', 
      overflow: 'hidden', 
      background: 'var(--bg-primary)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }}>
      {/* Animated Background Elements */}
      <div style={{ 
        position: 'absolute', 
        top: 0, 
        left: 0, 
        right: 0, 
        bottom: 0,
        background: `
          radial-gradient(circle at 20% 80%, rgba(99, 102, 241, 0.1) 0%, transparent 50%),
          radial-gradient(circle at 80% 20%, rgba(16, 185, 129, 0.1) 0%, transparent 50%),
          radial-gradient(circle at 40% 40%, rgba(139, 92, 246, 0.05) 0%, transparent 50%)
        `,
        pointerEvents: 'none'
      }}></div>
      
      {/* Floating Elements */}
      <div className="float-animation" style={{ 
        position: 'absolute', 
        top: '15%', 
        left: '15%', 
        width: '120px', 
        height: '120px', 
        background: 'var(--gradient-primary)', 
        borderRadius: '50%', 
        opacity: 0.1,
        filter: 'blur(25px)'
      }}></div>
      
      <div className="float-animation" style={{ 
        position: 'absolute', 
        bottom: '15%', 
        right: '15%', 
        width: '180px', 
        height: '180px', 
        background: 'var(--gradient-secondary)', 
        borderRadius: '50%', 
        opacity: 0.1,
        filter: 'blur(35px)',
        animationDelay: '1.5s'
      }}></div>

      <div className="container d-flex justify-content-center align-items-center" style={{ zIndex: 1, position: 'relative' }}>
        <div className="glass-effect shadow-xl" style={{ 
          minWidth: 400, 
          maxWidth: 500,
          borderRadius: 'var(--radius-2xl)',
          padding: 'var(--spacing-2xl)',
          border: '1px solid rgba(255, 255, 255, 0.1)'
        }}>
          {/* Header */}
          <div className="text-center mb-4">
            <div className="mb-3">
              <div className="d-inline-block p-3 rounded-circle bg-gradient-secondary text-white mb-3 float-animation" style={{ fontSize: '2.5rem' }}>
                <FaUserPlus />
              </div>
            </div>
            <h2 className="gradient-text mb-2">Create Account</h2>
            <p className="text-muted">Join our pharmacy community today</p>
          </div>

          {/* Error Alert */}
          {error && (
            <div className="alert alert-danger d-flex align-items-center mb-4" role="alert">
              <div className="me-2">⚠️</div>
              <div>{error}</div>
            </div>
          )}

          {/* Signup Form */}
          <form onSubmit={(e) => { e.preventDefault(); handleSignup(); }}>
            <div className="mb-3">
              <label className="form-label fw-bold text-muted d-flex align-items-center">
                <FaUser className="me-2" />
                Username
              </label>
              <div className="input-group">
                <span className="input-group-text bg-transparent border-end-0">
                  <FaUser className="text-muted" />
                </span>
                <input 
                  name="username" 
                  className="form-control border-start-0" 
                  placeholder="Choose a username" 
                  onChange={handleChange}
                  required
                />
              </div>
            </div>

            <div className="mb-3">
              <label className="form-label fw-bold text-muted d-flex align-items-center">
                <FaEnvelope className="me-2" />
                Email (Optional)
              </label>
              <div className="input-group">
                <span className="input-group-text bg-transparent border-end-0">
                  <FaEnvelope className="text-muted" />
                </span>
                <input 
                  name="email" 
                  type="email"
                  className="form-control border-start-0" 
                  placeholder="Enter your email" 
                  onChange={handleChange}
                />
              </div>
            </div>

            <div className="mb-3">
              <label className="form-label fw-bold text-muted d-flex align-items-center">
                <FaLock className="me-2" />
                Password
              </label>
              <div className="input-group">
                <span className="input-group-text bg-transparent border-end-0">
                  <FaLock className="text-muted" />
                </span>
                <input 
                  name="password" 
                  className="form-control border-start-0" 
                  placeholder="Create a strong password" 
                  type={showPassword ? "text" : "password"}
                  onChange={handleChange}
                  required
                />
                <button 
                  type="button"
                  className="btn btn-outline-secondary border-start-0"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <FaEyeSlash /> : <FaEye />}
                </button>
              </div>
            </div>

            <div className="mb-3">
              <label className="form-label fw-bold text-muted d-flex align-items-center">
                <FaLock className="me-2" />
                Confirm Password
              </label>
              <div className="input-group">
                <span className="input-group-text bg-transparent border-end-0">
                  <FaLock className="text-muted" />
                </span>
                <input 
                  name="confirmPassword" 
                  className="form-control border-start-0" 
                  placeholder="Confirm your password" 
                  type={showConfirmPassword ? "text" : "password"}
                  onChange={handleChange}
                  required
                />
                <button 
                  type="button"
                  className="btn btn-outline-secondary border-start-0"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                >
                  {showConfirmPassword ? <FaEyeSlash /> : <FaEye />}
                </button>
              </div>
            </div>

            <div className="mb-4">
              <label className="form-label fw-bold text-muted d-flex align-items-center">
                <FaUserShield className="me-2" />
                Account Type
              </label>
              <div className="input-group">
                <span className="input-group-text bg-transparent border-end-0">
                  <FaUserShield className="text-muted" />
                </span>
                <select 
                  name="role" 
                  className="form-select border-start-0" 
                  onChange={handleChange}
                  value={form.role}
                >
                  <option value="customer">Customer</option>
                  <option value="admin">Administrator</option>
                </select>
              </div>
            </div>

            <button 
              className="btn btn-modern w-100 mb-3" 
              onClick={handleSignup}
              disabled={isLoading}
              style={{ minHeight: '48px' }}
            >
              {isLoading ? (
                <div className="d-flex align-items-center justify-content-center">
                  <div className="loading-spinner me-2" style={{ width: '20px', height: '20px' }}></div>
                  Creating Account...
                </div>
              ) : (
                <div className="d-flex align-items-center justify-content-center">
                  <FaUserPlus className="me-2" />
                  Create Account
                </div>
              )}
            </button>
          </form>

          {/* Login Link */}
          <div className="text-center mt-4">
            <p className="text-muted mb-0">
              Already have an account?{' '}
              <Link to="/login" className="text-primary fw-bold" style={{ textDecoration: 'none' }}>
                Sign In
              </Link>
            </p>
          </div>

          {/* Terms and Privacy */}
          <div className="text-center mt-3">
            <p className="text-muted small">
              By creating an account, you agree to our{' '}
              <Link to="/terms" className="text-primary">Terms of Service</Link>
              {' '}and{' '}
              <Link to="/privacy" className="text-primary">Privacy Policy</Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Signup;
