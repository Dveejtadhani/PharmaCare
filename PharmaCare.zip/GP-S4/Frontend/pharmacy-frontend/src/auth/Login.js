import React, { useState } from "react";
import { FaUser, FaLock, FaUserShield, FaEye, FaEyeSlash, FaSignInAlt } from 'react-icons/fa';
import { Link } from 'react-router-dom';

const Login = () => {
  const [form, setForm] = useState({ username: "", password: "", role: "customer" });
  const [error, setError] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleLogin = async () => {
    setError("");
    setIsLoading(true);
    
    try {
      const res = await fetch("http://localhost:8000/api/login/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      
      if (res.ok) {
        localStorage.setItem("user", JSON.stringify(data));
        if (form.role === "admin") {
          window.location.href = "/dashboard";
        } else {
          window.location.href = "/customer";
        }
      } else {
        setError(data.error || "Login failed");
      }
    } catch (err) {
      setError("Network error. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fade-in" style={{ 
      position: 'relative', 
      minHeight: '100vh', 
      overflow: 'hidden', 
      background: 'var(--bg-primary)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }}>
      {/* Animated Background Elements */}
      <div style={{ 
        position: 'absolute', 
        top: 0, 
        left: 0, 
        right: 0, 
        bottom: 0,
        background: `
          radial-gradient(circle at 20% 80%, rgba(99, 102, 241, 0.1) 0%, transparent 50%),
          radial-gradient(circle at 80% 20%, rgba(16, 185, 129, 0.1) 0%, transparent 50%),
          radial-gradient(circle at 40% 40%, rgba(139, 92, 246, 0.05) 0%, transparent 50%)
        `,
        pointerEvents: 'none'
      }}></div>
      
      {/* Floating Elements */}
      <div className="float-animation" style={{ 
        position: 'absolute', 
        top: '10%', 
        left: '10%', 
        width: '100px', 
        height: '100px', 
        background: 'var(--gradient-primary)', 
        borderRadius: '50%', 
        opacity: 0.1,
        filter: 'blur(20px)'
      }}></div>
      
      <div className="float-animation" style={{ 
        position: 'absolute', 
        bottom: '10%', 
        right: '10%', 
        width: '150px', 
        height: '150px', 
        background: 'var(--gradient-secondary)', 
        borderRadius: '50%', 
        opacity: 0.1,
        filter: 'blur(30px)',
        animationDelay: '1s'
      }}></div>

      <div className="container d-flex justify-content-center align-items-center" style={{ zIndex: 1, position: 'relative' }}>
        <div className="glass-effect shadow-xl" style={{ 
          minWidth: 350, 
          maxWidth: 450,
          borderRadius: 'var(--radius-2xl)',
          padding: 'var(--spacing-2xl)',
          border: '1px solid rgba(255, 255, 255, 0.1)'
        }}>
          {/* Header */}
          <div className="text-center mb-4">
            <div className="mb-3">
              <div className="d-inline-block p-3 rounded-circle bg-gradient-primary text-white mb-3 float-animation" style={{ fontSize: '2.5rem' }}>
                <FaSignInAlt />
              </div>
            </div>
            <h2 className="gradient-text mb-2">Welcome Back</h2>
            <p className="text-muted">Sign in to your account to continue</p>
          </div>

          {/* Error Alert */}
          {error && (
            <div className="alert alert-danger d-flex align-items-center mb-4" role="alert">
              <div className="me-2">⚠️</div>
              <div>{error}</div>
            </div>
          )}

          {/* Login Form */}
          <form onSubmit={(e) => { e.preventDefault(); handleLogin(); }}>
            <div className="mb-3">
              <label className="form-label fw-bold text-muted d-flex align-items-center">
                <FaUser className="me-2" />
                Username
              </label>
              <div className="input-group">
                <span className="input-group-text bg-transparent border-end-0">
                  <FaUser className="text-muted" />
                </span>
                <input 
                  name="username" 
                  className="form-control border-start-0" 
                  placeholder="Enter your username" 
                  onChange={handleChange}
                  required
                />
              </div>
            </div>

            <div className="mb-3">
              <label className="form-label fw-bold text-muted d-flex align-items-center">
                <FaLock className="me-2" />
                Password
              </label>
              <div className="input-group">
                <span className="input-group-text bg-transparent border-end-0">
                  <FaLock className="text-muted" />
                </span>
                <input 
                  name="password" 
                  className="form-control border-start-0" 
                  placeholder="Enter your password" 
                  type={showPassword ? "text" : "password"}
                  onChange={handleChange}
                  required
                />
                <button 
                  type="button"
                  className="btn btn-outline-secondary border-start-0"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <FaEyeSlash /> : <FaEye />}
                </button>
              </div>
            </div>

            <div className="mb-4">
              <label className="form-label fw-bold text-muted d-flex align-items-center">
                <FaUserShield className="me-2" />
                Login As
              </label>
              <div className="input-group">
                <span className="input-group-text bg-transparent border-end-0">
                  <FaUserShield className="text-muted" />
                </span>
                <select 
                  name="role" 
                  className="form-select border-start-0" 
                  onChange={handleChange}
                  value={form.role}
                >
                  <option value="customer">Customer</option>
                  <option value="admin">Administrator</option>
                </select>
              </div>
            </div>

            <button 
              className="btn btn-modern w-100 mb-3" 
              onClick={handleLogin}
              disabled={isLoading}
              style={{ minHeight: '48px' }}
            >
              {isLoading ? (
                <div className="d-flex align-items-center justify-content-center">
                  <div className="loading-spinner me-2" style={{ width: '20px', height: '20px' }}></div>
                  Signing In...
                </div>
              ) : (
                <div className="d-flex align-items-center justify-content-center">
                  <FaSignInAlt className="me-2" />
                  Sign In
                </div>
              )}
            </button>
          </form>

          {/* Sign Up Link */}
          <div className="text-center mt-4">
            <p className="text-muted mb-0">
              Don't have an account?{' '}
              <Link to="/signup" className="text-primary fw-bold" style={{ textDecoration: 'none' }}>
                Create Account
              </Link>
            </p>
          </div>

          {/* Additional Links */}
          <div className="text-center mt-3">
            <Link to="/forgot-password" className="text-muted small" style={{ textDecoration: 'none' }}>
              Forgot your password?
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
