// import logo from './logo.svg';
import './App.css';
// import React, { useState } from "react";
import AdminNavbar from "./admin/Navbar";
import Medicines from "./admin/Medicines";
import StockOrders from "./admin/StockOrders";
import CustomerOrders from "./admin/CustomerOrders";
import Dashboard from "./admin/Dashboard";
import Login from "./auth/Login";
import Signup from "./auth/Signup";
import BrowseMedicine from "./customer/BrowseMedicine";
import CustomerRoutes from "./customer/CustomerRoutes";

import { BrowserRouter as Router, Routes, Route, useLocation } from "react-router-dom";


function AppRoutes() {
  const location = useLocation();
  // Show navbar on admin pages (now at root level)
  const adminPaths = [
    '/dashboard', '/medicines', '/stock-orders', '/customer-orders'
  ];
  const hideNavbar = !adminPaths.some(path => location.pathname.startsWith(path));
  return (
    <>
      {!hideNavbar && <AdminNavbar />}
      <div className="container mt-4">
        <Routes>
          {/* Auth routes */}
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />

          {/* Customer routes */}
          <Route path="/customer/*" element={<CustomerRoutes />} />

          {/* Admin routes at root level */}
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/medicines" element={<Medicines />} />
          <Route path="/stock-orders" element={<StockOrders />} />
          <Route path="/customer-orders" element={<CustomerOrders />} />

          {/* Default route */}
          <Route path="/" element={<Login/>} />
        </Routes>
      </div>
    </>
  );
}

function App() {
  return (
    <Router>
      <AppRoutes />
    </Router>
  );
}

export default App;
